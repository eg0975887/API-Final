API Final

Github Link: https://github.com/eg0975887/API-Final

1. To Start input your email

2. Once eamil is submitted you can see the current data in the API 

3. Once there you can choose to Add or Edit or Delete the info displayed above the links

    3a. The Add Link will give you a form to fill out that once submitted will add the data to the API table

    3b. The Edit Link will give you a form to fill out that once submitted will update the data on the API table

    3c. The Delete Link will automatically delete any data coresponding to which delete link you chose