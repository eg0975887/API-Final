<?php include ("model/database.php");
        include ("model/display_API.php");?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>

<body>
    <?php 
    include 'view/nav.php';
    
    if(isset($_GET['Email'])) {
        $apiKey = bin2hex(random_bytes(16)); // Generates a 32-character hex string
    echo "API Key: " . $apiKey;
        $email = $_GET['Email'];
    header("location:./index.php?email=$email&api=$apiKey");
    } 
    else if (isset($_GET['email']) && isset($_GET['api']))
    {
        // echo( ' Email and API found');
        $answer=getAPIs();
        // print_r($answer);
        $val0 = 'corpapi_ID';
        $val1 = 1;
        $val2 = 2;
        $val3 = 3;
        $val4 = 0;
        foreach ($answer as $key) {
            // print_r($key); echo('/---------/');
            echo ("<br><p>$key[$val0] - Company Name: $key[$val1], Company Market: $key[$val2], Founder: $key[$val3]</p> <a href='?change=1'>Add</a> / <a href='?change=2&edit=$val4'>Edit</a> / <a href='?change=3&delete=$val4 '>Delete</a><br>");
            $val4 = $val4 + 1;
            // foreach ($key as $api) {
            //     echo ("<p>$api[0] - Company Name: $api[$val1], Company Market: $api[$val2], Founder: $api[$val3]</p><br>");
                
            // }
            // $val0 = $val0 + 1;
        } 
    }
    else if (isset($_GET['change']))
    {
        $hidden = $_GET['change'];
        if ($_GET['change'] == 1) {
            include 'view/addData.php';
        } else if ($_GET['change'] == 2) {

        } else {
            
        }
    }
    else if (isset($_GET['hidden']))
    {
        global $db;
        $Name = $_GET['Name'];
        $Market = $_GET['Market'];
        $Founder = $_GET['Founder'];
        $sql = "INSERT INTO `corpapi` (`corpapi_ID`, `corpapi_Name`, `corpapi_Market`, `corpapi_Founder`) VALUES ($Name, $Market, $Founder)";
        $qry = $db->query($sql);  // returns PDOstatement
        // var_dump($qry);
         
       

        // Return the array of products
        // print_r($products);
        return $result;
    }
    else if (!isset($_GET['Email'])) {
        include 'view/RegPage.php';
    }
    

    
    ?>

</body>
</html>