<?php

       // dsn stands for Data Source Name - connection string to the database
       $dsn = "mysql:host=localhost;dbname=apifinal";
       $username = "root";
       $password = "";

       try{
           $db = new PDO($dsn, $username, $password);
        //    echo ("connected");
       } 
           catch(PDOException $e)
       {
           echo ("Didn't work");
       }

?>