<?php
function getAPIs()
    {

        
      
        global $db;
        $sql = "select * from corpapi";
        $qry = $db->query($sql);  // returns PDOstatement
        // var_dump($qry);
         $result = $qry->fetchAll(); 
       

        // Return the array of products
        // print_r($products);
        return $result;
    }
    ?>