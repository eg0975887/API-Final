<!-- 
    Author: Ebbett Grant
    Last Changed: 11/29/2023
 -->

    <h3>Please Enter your name for a API</h3>
    <form method="get" action="">
    <div class="mb-3">
        <label for="Email" class="form-label">Email</label>
        <input type="email" class="form-control" id="Email" name="Email">
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>


