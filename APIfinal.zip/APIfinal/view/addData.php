<?php $hidden ?>
<form method="get" action=".">
    <div class="mb-3">
        <label for="Name" class="form-label">Company Name</label>
        <input type="text" class="form-control" id="Name" name="Name">
    </div>
    <div class="mb-3">
        <label for="Market" class="form-label">Company Market</label>
        <input type="text" class="form-control" id="Market" name="Market">
    </div>
    <div class="mb-3">
        <label for="Founder" class="form-label">Company Founder</label>
        <input type="text" class="form-control" id="Founder" name="Founder">
    </div>
    <input type="hidden" name="hidden" value="1">
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>